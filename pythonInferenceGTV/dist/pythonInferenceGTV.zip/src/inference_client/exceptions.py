class InferenceServerError(Exception):
    pass

class JobExecError(Exception):
    pass