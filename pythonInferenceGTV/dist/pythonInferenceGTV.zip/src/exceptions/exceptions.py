class LastPostFailed(Exception):
    pass

class InferenceServerError(Exception):
    pass

class JobExecError(Exception):
    pass