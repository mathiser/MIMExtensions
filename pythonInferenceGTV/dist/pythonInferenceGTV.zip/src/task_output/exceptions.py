class NiftiNamingError(Exception):
    pass

class PredictionLoadError(Exception):
    pass